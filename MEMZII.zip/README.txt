███╗░░░███╗███████╗███╗░░░███╗███████╗██╗██╗
████╗░████║██╔════╝████╗░████║╚════██║██║██║
██╔████╔██║█████╗░░██╔████╔██║░░███╔═╝██║██║
██║╚██╔╝██║██╔══╝░░██║╚██╔╝██║██╔══╝░░██║██║
██║░╚═╝░██║███████╗██║░╚═╝░██║███████╗██║██║
╚═╝░░░░░╚═╝╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═╝╚═╝

Created by: Lizkit
Coding Language: C++
Programs Used: Dev-C++.
Supported OS: Windows XP and over.
Tested On: Windows XP 32-Bit.
This program will not work with previous versions.

THIS PROGRAM IS MALICIOUS AND CAN CAUSE SIGNIFICANT DAMAGE TO YOUR SYSTEM.
UPON EXECUTING, YOU WILL BE GREETED WITH A WARNING TO CONFIRM YOUR DECISION.

This program has flashing lights and loud noises, and is my personal spin off the classic MEMZ trojan, featuring new GDI payloads.
All credits go towards Leurak for creating the original masterpiece.

It is also recommended that the virtual machine or system is connected to the internet for the URLs to load successfully.

Enjoy :D

(I know the batch file does not create the EXE file, I was too lazy.)