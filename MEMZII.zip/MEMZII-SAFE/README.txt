███╗░░░███╗███████╗███╗░░░███╗███████╗██╗██╗
████╗░████║██╔════╝████╗░████║╚════██║██║██║
██╔████╔██║█████╗░░██╔████╔██║░░███╔═╝██║██║
██║╚██╔╝██║██╔══╝░░██║╚██╔╝██║██╔══╝░░██║██║
██║░╚═╝░██║███████╗██║░╚═╝░██║███████╗██║██║
╚═╝░░░░░╚═╝╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═╝╚═╝

This is the safe version of MEMZII.

Although the warning still states its dangerous, it is not going to cause any damage whatsoever.

Thank you for trying MEMZII. :D